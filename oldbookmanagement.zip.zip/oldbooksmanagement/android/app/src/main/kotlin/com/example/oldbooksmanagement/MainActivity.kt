package com.example.oldbooksmanagement

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
