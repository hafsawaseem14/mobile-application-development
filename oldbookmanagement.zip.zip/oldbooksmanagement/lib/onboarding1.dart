import 'package:flutter/material.dart';
import 'onboardingtwo.dart'; // <--- Agli file ka sahi naam yahan import karein

class OnboardingOne extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("📖", style: TextStyle(fontSize: 100)),
            const SizedBox(height: 50),
            const Text(
              "Find Your Next Read",
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1A1D2E)
              ),
            ),
            const SizedBox(height: 15),
            const Text(
                "Browse thousands of used books and get them at half price from local sellers.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF6B7280), fontSize: 16)
            ),
            const SizedBox(height: 60),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF3B2FCC),
                  minimumSize: const Size(double.infinity, 55),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))
              ),
              onPressed: () {
                // Navigation logic yahan add ki hai
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => OnboardingTwo()), // Agli class ka naam sahi likhein
                );
              },
              child: const Text("Next", style: TextStyle(color: Colors.white, fontSize: 18)),
            )
          ],
        ),
      ),
    );
  }
}