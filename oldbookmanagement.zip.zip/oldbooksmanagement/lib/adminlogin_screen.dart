import 'package:flutter/material.dart';
// 1. IS LINE KO LAZMI CHECK KAREIN:
// Agar aapki file ka naam 'admindashboard_screen.dart' hai to ye sahi hai
import 'admindashboard_screen.dart';

class AdminLogin extends StatelessWidget {
  const AdminLogin({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30),
          child: Column(
            children: [
              const SizedBox(height: 20),
              const Icon(Icons.admin_panel_settings, size: 80, color: Color(0xFF3B2FCC)),
              const SizedBox(height: 20),
              const Text(
                "Admin Portal",
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const Text("Authorized access only", style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 40),

              TextField(
                decoration: InputDecoration(
                  hintText: "Admin ID",
                  filled: true,
                  fillColor: const Color(0xFFF5F6FA),
                  prefixIcon: const Icon(Icons.person_outline),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 20),

              TextField(
                obscureText: true,
                decoration: InputDecoration(
                  hintText: "Password",
                  filled: true,
                  fillColor: const Color(0xFFF5F6FA),
                  prefixIcon: const Icon(Icons.lock_outline),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 40),

              // ADMIN LOGIN BUTTON
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1A1D2E),
                  minimumSize: const Size(double.infinity, 55),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  // 2. NAAM CHECK KAREIN:
                  // Agar red line yahan hai, to admindashboard_screen.dart mein
                  // ja kar class ka naam dekhein aur wahi yahan likhein.
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const AdminDashboard()),
                  );
                },
                child: const Text("Admin Login", style: TextStyle(color: Colors.white, fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}