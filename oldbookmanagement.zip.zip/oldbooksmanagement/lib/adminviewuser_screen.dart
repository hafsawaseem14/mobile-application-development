import 'package:flutter/material.dart';

class AdminViewUser extends StatelessWidget {
  final String name;
  final String email;

  const AdminViewUser({super.key, required this.name, required this.email});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF3B2FCC),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("User Details", style: TextStyle(color: Colors.white)),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 1. Blue Profile Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(bottom: 40),
              decoration: const BoxDecoration(
                color: Color(0xFF3B2FCC),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: Colors.white.withOpacity(0.2),
                    child: Text(
                      name[0].toUpperCase(),
                      style: const TextStyle(fontSize: 40, color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(height: 15),
                  Text(
                    name,
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  Text(
                    email,
                    style: TextStyle(fontSize: 16, color: Colors.white.withOpacity(0.8)),
                  ),
                ],
              ),
            ),

            // 2. Account Overview Section
            Padding(
              padding: const EdgeInsets.all(25.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Account Overview", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      _buildInfoCard("Status", "Active", Colors.green.shade50, Colors.green),
                      const SizedBox(width: 15),
                      _buildInfoCard("Role", "User", Colors.blue.shade50, Colors.blue),
                    ],
                  ),
                  const SizedBox(height: 15),
                  Row(
                    children: [
                      _buildInfoCard("Books Sold", "08", Colors.orange.shade50, Colors.orange),
                      const SizedBox(width: 15),
                      _buildInfoCard("Joined", "Jan 2026", Colors.purple.shade50, Colors.purple),
                    ],
                  ),

                  const SizedBox(height: 30),
                  // 3. Actions Section
                  const Text("Actions", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 15),
                  _buildActionButton(Icons.block, "Block User Account", Colors.orange),
                  _buildActionButton(Icons.delete_forever, "Delete User Permanently", Colors.red),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Info Card Widget
  Widget _buildInfoCard(String title, String value, Color bgColor, Color textColor) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: TextStyle(color: Colors.grey.shade700, fontSize: 13)),
            const SizedBox(height: 5),
            Text(value, style: TextStyle(color: textColor, fontWeight: FontWeight.bold, fontSize: 16)),
          ],
        ),
      ),
    );
  }

  // Action Button Widget
  Widget _buildActionButton(IconData icon, String label, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      width: double.infinity,
      child: OutlinedButton.icon(
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 15),
          side: BorderSide(color: Colors.grey.shade200),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          alignment: Alignment.centerLeft,
        ),
        onPressed: () {},
        icon: Icon(icon, color: color),
        label: Text(label, style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.w500)),
      ),
    );
  }
}