import 'package:flutter/material.dart';

class BookDetailScreen extends StatelessWidget {
  final String bookName;
  final String bookPrice;
  final String sellerName;

  // Constructor jo data lega
  const BookDetailScreen({
    super.key,
    required this.bookName,
    required this.bookPrice,
    required this.sellerName
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Section (Header)
            Stack(
              children: [
                Container(
                  height: 350,
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    color: Color(0xFFEEF0FF),
                    borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30), bottomRight: Radius.circular(30)),
                  ),
                  child: const Center(child: Icon(Icons.book, size: 120, color: Color(0xFF3B2FCC))),
                ),
                SafeArea(
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new),
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
              ],
            ),

            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(bookName, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), // Dynamic Name
                  const SizedBox(height: 8),
                  Text(bookPrice, style: const TextStyle(fontSize: 22, color: Color(0xFFFF6B35), fontWeight: FontWeight.bold)), // Dynamic Price

                  const SizedBox(height: 25),
                  const Text("Description", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const Text("This book is available in good condition.", style: TextStyle(color: Colors.grey)),

                  const SizedBox(height: 25),

                  // Seller Info Section (Dynamic Seller)
                  Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(color: const Color(0xFFF5F6FA), borderRadius: BorderRadius.circular(15)),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: const Color(0xFF3B2FCC),
                          child: Text(sellerName[0], style: const TextStyle(color: Colors.white)), // Seller ka pehla letter
                        ),
                        const SizedBox(width: 15),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(sellerName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), // Dynamic Seller Name
                            const Text("Verified Seller", style: TextStyle(color: Colors.grey, fontSize: 12)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}