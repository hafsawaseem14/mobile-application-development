import 'package:flutter/material.dart';
// Yahan maine import active kar diya hai
import 'bookdetail_screen.dart';

class BrowseScreen extends StatelessWidget {
  const BrowseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Categories ka data
    final List<Map<String, dynamic>> categories = [
      {"name": "Fiction", "count": "142 books", "icon": Icons.menu_book, "color": Colors.orange},
      {"name": "Science", "count": "89 books", "icon": Icons.biotech, "color": Colors.blue},
      {"name": "Finance", "count": "56 books", "icon": Icons.savings, "color": Colors.amber},
      {"name": "History", "count": "73 books", "icon": Icons.history_edu, "color": Colors.brown},
      {"name": "Children", "count": "110 books", "icon": Icons.child_care, "color": Colors.yellow},
      {"name": "Urdu", "count": "94 books", "icon": Icons.dark_mode, "color": Colors.indigo},
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // 1. Blue Header (Customized)
          Container(
            padding: const EdgeInsets.only(top: 60, left: 20, right: 20, bottom: 25),
            decoration: const BoxDecoration(
              color: Color(0xFF3B2FCC),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Column(
              children: [
                const Text(
                  "Browse",
                  style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF5F6FA),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: const TextField(
                    decoration: InputDecoration(
                      icon: Icon(Icons.search, color: Colors.grey),
                      hintText: "Search categories...",
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 2. Categories Grid
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                childAspectRatio: 0.85,
              ),
              itemCount: categories.length,
              itemBuilder: (context, index) {
                return _buildCategoryCard(context, categories[index]);
              },
            ),
          ),
        ],
      ),

      // 3. Bottom Navigation Bar
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF3B2FCC),
        unselectedItemColor: Colors.grey,
        currentIndex: 1,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: "Browse"),
          BottomNavigationBarItem(icon: Icon(Icons.add_box_outlined), label: "Sell"),
          BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_outline), label: "Chat"),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: "Profile"),
        ],
      ),
    );
  }

  // 4. CONNECTION LOGIC (FIXED)
  Widget _buildCategoryCard(BuildContext context, Map<String, dynamic> cat) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const BookDetailScreen(
              bookName: "Sample Book", // Yahan dummy data bhej rahe hain
              bookPrice: "Rs. 500",
              sellerName: "Ali Ahmed",
            ),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFF8F9FF),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFE8EBFF), width: 1),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(cat['icon'], size: 50, color: cat['color']),
            const SizedBox(height: 15),
            Text(
              cat['name'],
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 5),
            Text(
              cat['count'],
              style: const TextStyle(color: Colors.grey, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}