import 'package:flutter/material.dart';

class MyBooksScreen extends StatelessWidget {
  const MyBooksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // 1. Blue Header (Customized)
          Container(
            padding: const EdgeInsets.only(top: 60, left: 20, right: 20, bottom: 25),
            decoration: const BoxDecoration(
              color: Color(0xFF3B2FCC),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
                const Expanded(
                  child: Text(
                    "My Books",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(width: 40), // Balance ke liye
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                // 2. Status Tabs (Active, Sold, Pending)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildTab("Active (3)", true),
                    _buildTab("Sold (7)", false),
                    _buildTab("Pending (1)", false),
                  ],
                ),
              ],
            ),
          ),

          // 3. Books List
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              children: [
                _buildBookItem("Rich Dad Poor Dad", "Rs. 350", "Finance", "Active", Colors.green),
                _buildBookItem("Atomic Habits", "Rs. 280", "Self-Help", "Pending", Colors.orange),
                _buildBookItem("The Alchemist", "Rs. 200", "Fiction", "Active", Colors.green),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Tab Widget
  Widget _buildTab(String label, bool isActive) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      decoration: BoxDecoration(
        color: isActive ? const Color(0xFF3B2FCC) : const Color(0xFFF5F6FA),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: isActive ? Colors.white : Colors.black54,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // Book Item Card
  Widget _buildBookItem(String title, String price, String category, String status, Color statusColor) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F9FF),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE8EBFF)),
      ),
      child: Row(
        children: [
          // Book Icon/Image Placeholder
          Container(
            height: 80,
            width: 70,
            decoration: BoxDecoration(
              color: Colors.blue.shade100,
              borderRadius: BorderRadius.circular(15),
            ),
            child: const Icon(Icons.book, size: 40, color: Color(0xFF3B2FCC)),
          ),
          const SizedBox(width: 15),
          // Details
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 5),
                Text("$price · $category", style: const TextStyle(color: Colors.grey)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _buildActionButton("Edit", const Color(0xFF3B2FCC)),
                    const SizedBox(width: 10),
                    _buildActionButton(status == "Active" ? "Mark Sold" : "Delete",
                        status == "Active" ? Colors.orange : Colors.red),
                  ],
                ),
              ],
            ),
          ),
          // Status Text
          RotatedBox(
            quarterTurns: 0,
            child: Text(
              status,
              style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
    );
  }
}