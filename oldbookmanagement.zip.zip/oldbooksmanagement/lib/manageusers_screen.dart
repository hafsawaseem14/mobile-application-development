import 'package:flutter/material.dart';
// AGAR ERROR AYE: To line niche wali line par click karke Quick Fix (Bulb) se sahi file select karein
import 'adminviewuser_screen.dart';

class ManageUserScreen extends StatelessWidget {
  const ManageUserScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Dummy data
    final List<Map<String, dynamic>> users = [
      {"name": "Ali Hassan", "email": "ali@gmail.com", "status": "Active", "listings": "12", "color": Colors.indigo},
      {"name": "ahmed Riaz", "email": "ahmed@gmail.com", "status": "Active", "listings": "7", "color": Colors.red},
      {"name": "Abdullah Khan", "email": "abdullah@gmail.com", "status": "Banned", "listings": "0", "color": Colors.blueGrey},
      {"name": "Farooq", "email": "farooq@gmail.com", "status": "Active", "listings": "23", "color": Colors.green},
      {"name": "Imran Qureshi", "email": "imran@gmail.com", "status": "Suspended", "listings": "5", "color": Colors.purple},
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // 1. Blue Header with Curved Bottom
          Container(
            width: double.infinity,
            padding: const EdgeInsets.only(top: 60, left: 25, right: 25, bottom: 30),
            decoration: const BoxDecoration(
              color: Color(0xFF3B2FCC),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(40),
                bottomRight: Radius.circular(40),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Manage Users",
                  style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                Container(
                  height: 55,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: const TextField(
                    decoration: InputDecoration(
                      hintText: "Search users...",
                      hintStyle: TextStyle(color: Colors.grey),
                      prefixIcon: Icon(Icons.search_rounded, color: Colors.black87, size: 30),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 15),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 2. Filter Tabs
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 25),
            child: Row(
              children: [
                _buildFilterChip("All (1248)", true),
                const SizedBox(width: 10),
                _buildFilterChip("Active", false),
                const SizedBox(width: 10),
                _buildFilterChip("Banned", false),
              ],
            ),
          ),

          // 3. User List
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 25),
              itemCount: users.length,
              separatorBuilder: (context, index) => const Divider(height: 30, color: Color(0xFFF1F1F1)),
              itemBuilder: (context, index) {
                return _buildUserRow(context, users[index]);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, bool isSelected) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      decoration: BoxDecoration(
        color: isSelected ? const Color(0xFF3B2FCC) : const Color(0xFFF5F6FA),
        borderRadius: BorderRadius.circular(25),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.grey.shade600,
          fontWeight: FontWeight.bold,
          fontSize: 14,
        ),
      ),
    );
  }

  Widget _buildUserRow(BuildContext context, Map<String, dynamic> user) {
    bool isBanned = user['status'] == "Banned";
    bool isSuspended = user['status'] == "Suspended";

    return Row(
      children: [
        CircleAvatar(
          radius: 26,
          backgroundColor: user['color'],
          child: Text(
            user['name']!.split(' ').map((e) => e[0]).join().toUpperCase(),
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
          ),
        ),
        const SizedBox(width: 15),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(user['name']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: Colors.black87)),
              Text("${user['listings']} listings", style: const TextStyle(color: Colors.grey, fontSize: 14)),
            ],
          ),
        ),
        Text(
          user['status']!,
          style: TextStyle(
            color: isBanned ? Colors.red : (isSuspended ? Colors.orange : Colors.green),
            fontWeight: FontWeight.w500,
            fontSize: 14,
          ),
        ),
        const SizedBox(width: 12),
        GestureDetector(
          onTap: () {
            // Navigator Fixed
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AdminViewUser(
                  name: user['name']!,
                  email: user['email']!,
                ),
              ),
            );
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
            decoration: BoxDecoration(
              color: isBanned ? const Color(0xFF00C48C) : (isSuspended ? const Color(0xFF3F3D56) : const Color(0xFF3B2FCC)),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              isBanned ? "Unban" : (isSuspended ? "Review" : "Manage"),
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ),
        ),
      ],
    );
  }
}