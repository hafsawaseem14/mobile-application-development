import 'package:flutter/material.dart';
import 'reset_pasword.dart';

class OtpScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Verify Email", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF3B2FCC))),
            SizedBox(height: 10),
            Text("Enter the 4-digit code sent to your email", style: TextStyle(color: Colors.grey)),
            SizedBox(height: 40),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(4, (index) => SizedBox(width: 60, child: TextField(textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold), decoration: InputDecoration(border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))))),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF3B2FCC),
                minimumSize: const Size(double.infinity, 55),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) =>  ResetPasswordScreen()),
                );
              },
              child: const Text("Verify Now", style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}