import 'package:flutter/material.dart';

class SignupScreen extends StatefulWidget {
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  bool _isPassVisible = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0,
          leading: IconButton(icon: Icon(Icons.arrow_back, color: Color(0xFF3B2FCC)), onPressed: () => Navigator.pop(context))),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Create Account", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF3B2FCC))),
            Text("Join our community of book lovers", style: TextStyle(color: Colors.grey)),
            SizedBox(height: 30),
            _inputField("Full Name", Icons.person_outline),
            _inputField("Email Address", Icons.email_outlined),
            _inputField("Phone Number", Icons.phone_android_outlined),
            TextField(
              obscureText: !_isPassVisible,
              decoration: InputDecoration(
                labelText: "Password",
                prefixIcon: Icon(Icons.lock_outline, color: Color(0xFF3B2FCC)),
                suffixIcon: IconButton(
                  icon: Icon(_isPassVisible ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _isPassVisible = !_isPassVisible),
                ),
              ),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF3B2FCC), minimumSize: Size(double.infinity, 55), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              onPressed: () {},
              child: Text("Sign Up", style: TextStyle(color: Colors.white, fontSize: 18)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _inputField(String label, IconData icon) => Padding(
    padding: EdgeInsets.only(bottom: 15),
    child: TextField(decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon, color: Color(0xFF3B2FCC)))),
  );
}