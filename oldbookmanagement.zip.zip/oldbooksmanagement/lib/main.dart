import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'splash_screen.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    if (kIsWeb) {
      // Agar aap Web par chala rahi hain, to yahan Firebase Console se
      // mili hui configuration settings daalni parti hain.
      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: "YOUR_API_KEY", // <--- Ye Firebase Console se milega
          appId: "YOUR_APP_ID",
          messagingSenderId: "YOUR_SENDER_ID",
          projectId: "YOUR_PROJECT_ID",
        ),
      );
    } else {
      // Android/Windows Desktop ke liye ye kaafi hai
      await Firebase.initializeApp();
    }
  } catch (e) {
    print("Firebase Initialization Error: $e");
  }

  runApp(const BookBazaarApp());
}

class BookBazaarApp extends StatelessWidget {
  const BookBazaarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BookBazaar',
      theme: ThemeData(
        primaryColor: const Color(0xFF3B2FCC),
        scaffoldBackgroundColor: const Color(0xFFF5F6FA),
      ),
      home: const SplashScreen(),
    );
  }
}