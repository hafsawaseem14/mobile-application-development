import 'package:flutter/material.dart';
import 'addbook_screen.dart';
import 'bookdetail_screen.dart';
import 'userprofile_screen.dart';
import 'browse_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text("Hello, Hafsa 👋", style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.bold)),
            Text("Let's find a book", style: TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
        actions: [
          IconButton(
              icon: const Icon(Icons.notifications_none, color: Colors.black),
              onPressed: () {}
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
                decoration: InputDecoration(
                    hintText: "Search books...",
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide.none
                    )
                )
            ),
            const SizedBox(height: 25),
            // Featured Card
            Container(
              height: 150,
              width: double.infinity,
              decoration: BoxDecoration(color: const Color(0xFF3B2FCC), borderRadius: BorderRadius.circular(20)),
              padding: const EdgeInsets.all(20),
              child: Row(children: const [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text("Big Sale!", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                  Text("Get 50% off on all fiction books", style: TextStyle(color: Colors.white70)),
                ])),
                Icon(Icons.auto_stories, color: Colors.white54, size: 80),
              ]),
            ),
            const SizedBox(height: 25),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text("Recent Arrivals", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text("See All", style: TextStyle(color: const Color(0xFF3B2FCC))),
            ]),
            const SizedBox(height: 15),
            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 15,
              mainAxisSpacing: 15,
              childAspectRatio: 0.7,
              children: [
                // Yahan hum 4 cheezain bhej rahay hain
                _bookItem(context, "Atomic Habits", "Rs. 550", "Ayesha Khan"),
                _bookItem(context, "The Great Gatsby", "Rs. 400", "Hamza Ali"),
              ],
            )
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) =>  BrowseScreen()),
            );
          }
          else if (index == 2) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AddBookScreen()),
            );
          }
          else if (index == 3) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const UserProfileScreen()),
            );
          }
        },
        selectedItemColor: const Color(0xFF3B2FCC),
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.explore), label: "Browse"),
          BottomNavigationBarItem(icon: Icon(Icons.add_box_outlined), label: "Sell"),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: "Profile"),
        ],
      ),
    );
  }

  // --- FIX: Yahan 'String seller' add kiya hai taake error khatam ho jaye ---
  Widget _bookItem(BuildContext context, String name, String price, String seller) => GestureDetector(
    onTap: () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => BookDetailScreen(
            bookName: name,
            bookPrice: price,
            sellerName: seller, // Ab ye error nahi dega
          ),
        ),
      );
    },
    child: Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
            child: Container(
                decoration: const BoxDecoration(
                    color: Color(0xFFEEF0FF),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(15))
                ),
                child: const Center(child: Icon(Icons.book, size: 40, color: Color(0xFF3B2FCC)))
            )
        ),
        Padding(
            padding: const EdgeInsets.all(10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold), maxLines: 1),
              Text(price, style: const TextStyle(color: Color(0xFFFF6B35), fontWeight: FontWeight.bold)),
            ])
        ),
      ]),
    ),
  );
}