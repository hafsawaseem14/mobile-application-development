import 'package:flutter/material.dart';
// Saare zaroori imports yahan hain
import 'mybooks_screen.dart';
import 'editprofile_screen.dart';
import 'logout_screen.dart';
import 'orderhistory_screen.dart';
import 'wishlist_screen.dart'; // Naya Wishlist import add ho gaya

class UserProfileScreen extends StatelessWidget {
  const UserProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // 1. Blue Header Section
          Container(
            width: double.infinity,
            padding: const EdgeInsets.only(top: 60, bottom: 30),
            decoration: const BoxDecoration(
              color: Color(0xFF3B2FCC),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Column(
              children: [
                const CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.white24,
                  child: Text("H", style: TextStyle(fontSize: 32, color: Colors.white, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 15),
                const Text("HAFSA", style: TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold)),
                const Text("hafsa@gmail.com • Lahore", style: TextStyle(color: Colors.white70, fontSize: 14)),
              ],
            ),
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  // 2. Stats Cards
                  Row(
                    children: [
                      _statCard("12", "Books Listed"),
                      const SizedBox(width: 15),
                      _statCard("7", "Books Sold"),
                    ],
                  ),
                  const SizedBox(height: 30),

                  // 3. Profile Menu List - Connections yahan hain

                  _menuItem(context, Icons.person_outline, "Edit Profile", () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const EditProfileScreen()),
                    );
                  }),

                  _menuItem(context, Icons.inventory_2_outlined, "My Books", () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const MyBooksScreen()),
                    );
                  }),

                  // WISHLIST KA CONNECTION YAHAN HAI
                  _menuItem(context, Icons.favorite_border, "Wishlist", () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const WishlistScreen()),
                    );
                  }),

                  _menuItem(context, Icons.assignment_outlined, "Order History", () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const OrderHistoryScreen()),
                    );
                  }),

                  const Divider(height: 40, thickness: 1),

                  // 4. Logout Connection
                  _menuItem(context, Icons.logout, "Logout", () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const LogoutScreen()),
                    );
                  }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Stats Card Widget
  Widget _statCard(String count, String label) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFFEEF0FF),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(count, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF3B2FCC))),
            const SizedBox(height: 5),
            Text(label, style: const TextStyle(color: Colors.grey, fontSize: 14)),
          ],
        ),
      ),
    );
  }

  // Menu Item Widget
  Widget _menuItem(BuildContext context, IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: title == "Logout" ? Colors.red : Colors.black),
      title: Text(
          title,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: title == "Logout" ? Colors.red : Colors.black,
          )
      ),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
      contentPadding: const EdgeInsets.symmetric(vertical: 5),
      onTap: onTap,
    );
  }
}