import 'package:flutter/material.dart';

class ResetPasswordScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 60),
            Text("New Password", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF3B2FCC))),
            Text("Set a strong password to secure your account", style: TextStyle(color: Colors.grey)),
            SizedBox(height: 30),
            TextField(obscureText: true, decoration: InputDecoration(labelText: "New Password", prefixIcon: Icon(Icons.lock_outline))),
            SizedBox(height: 15),
            TextField(obscureText: true, decoration: InputDecoration(labelText: "Confirm Password", prefixIcon: Icon(Icons.lock_reset))),
            SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF3B2FCC), minimumSize: Size(double.infinity, 55), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              onPressed: () {},
              child: Text("Update Password", style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}