import 'package:flutter/material.dart';
import 'onboarding_three.dart'; // Agli screen ka import

class OnboardingTwo extends StatelessWidget {
  const OnboardingTwo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 50),
            // Image Section
            Expanded(
              flex: 3,
              child: Center(
                child: Text("📚", style: TextStyle(fontSize: 100)), // Yahan aap apni image asset bhi laga sakti hain
              ),
            ),
            // Text Section
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  children: [
                    const Text(
                      "Find Your Favorite Books",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF1A1D2E)),
                    ),
                    const SizedBox(height: 15),
                    const Text(
                      "Explore a vast collection of second-hand books at the best prices.",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16, color: Color(0xFF6B7280)),
                    ),
                  ],
                ),
              ),
            ),
            // Bottom Button & Dots
            Padding(
              padding: const EdgeInsets.all(30),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Page Indicators (Dots)
                  Row(
                    children: [
                      _dot(false),
                      _dot(true), // Onboarding Two is active
                      _dot(false),
                    ],
                  ),
                  // Next Button
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF3B2FCC),
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(20),
                    ),
                    onPressed: () {
                      // Navigate to Onboarding Three
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => const OnboardingThree()),
                      );
                    },
                    child: const Icon(Icons.arrow_forward, color: Colors.white),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dot(bool isActive) {
    return Container(
      margin: const EdgeInsets.only(right: 5),
      height: 8,
      width: isActive ? 24 : 8,
      decoration: BoxDecoration(
        color: isActive ? const Color(0xFF3B2FCC) : const Color(0xFFBDBFFF),
        borderRadius: BorderRadius.circular(5),
      ),
    );
  }
}