import 'package:flutter/material.dart';
import 'manageusers_screen.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 1. Blue Header Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.only(top: 60, left: 25, right: 25, bottom: 30),
              decoration: const BoxDecoration(
                color: Color(0xFF3B2FCC),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Admin Panel", style: TextStyle(color: Colors.white70, fontSize: 14)),
                          Text("Overview", style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Row(
                        children: [
                          const Icon(Icons.notifications_active, color: Colors.amber, size: 28),
                          const SizedBox(width: 15),
                          CircleAvatar(
                            backgroundColor: Colors.white24,
                            child: const Text("UA", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                          ),
                        ],
                      )
                    ],
                  ),
                  const SizedBox(height: 30),

                  // Stats Cards Row 1
                  Row(
                    children: [
                      _statCard("1,248", "Total Users", Colors.white24),
                      const SizedBox(width: 15),
                      _statCard("3,891", "Books Listed", Colors.white24),
                    ],
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Stats Cards Row 2 (Sales & Pending)
                  Row(
                    children: [
                      _infoCard("Rs. 1.2M", "Total Sales", const Color(0xFFEEF0FF), const Color(0xFF3B2FCC)),
                      const SizedBox(width: 15),
                      _infoCard("14", "Pending Approval", const Color(0xFFFFF4F0), Colors.orange),
                    ],
                  ),
                  const SizedBox(height: 30),

                  const Text("Sales This Week", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 15),

                  // Simple Bar Chart Placeholder
                  Container(
                    height: 120,
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        _bar(40), _bar(60), _bar(80), _bar(50), _bar(100), _bar(70), _bar(90),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),

                  // Recent Reports Section
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Recent Reports", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      TextButton(onPressed: () {}, child: const Text("View All", style: TextStyle(color: Color(0xFF3B2FCC)))),
                    ],
                  ),

                  // Reports List
                  _reportTile("Spam listing reported", "New", Colors.red),
                  _reportTile("User complaint #234", "Open", Colors.orange),

                  const SizedBox(height: 20),

                  // Manage Users Navigation Button
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF3B2FCC),
                      minimumSize: const Size(double.infinity, 55),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    ),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => const ManageUserScreen()));
                    },
                    icon: const Icon(Icons.people, color: Colors.white),
                    label: const Text("Manage App Users", style: TextStyle(color: Colors.white, fontSize: 16)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widgets Helpers
  Widget _statCard(String value, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(15)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  Widget _infoCard(String value, String label, Color bgColor, Color textColor) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(15)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(value, style: TextStyle(color: textColor, fontSize: 18, fontWeight: FontWeight.bold)),
            Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  Widget _bar(double height) {
    return Container(width: 15, height: height, decoration: BoxDecoration(color: const Color(0xFF3B2FCC).withOpacity(0.5), borderRadius: BorderRadius.circular(5)));
  }

  Widget _reportTile(String title, String status, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15)),
      child: Row(
        children: [
          Icon(Icons.circle, color: color, size: 12),
          const SizedBox(width: 15),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w500))),
          Text(status, style: TextStyle(color: color, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}